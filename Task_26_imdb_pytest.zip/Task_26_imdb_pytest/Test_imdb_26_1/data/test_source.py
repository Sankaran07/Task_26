class Values:
    url = "https://www.imdb.com/search/name/"
    name_text = "kamal"
    date_from = '07-11-1962'
    date_to = '07-12-2023'

